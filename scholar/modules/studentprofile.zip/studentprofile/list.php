	<?php
		check_message(); 

		@$IDNO = $_GET['id'];
	?> 
		<style>
			th {
            padding: 5px;
            text-align: center;
        }
		</style>
<?php
	$id =  $_SESSION['USERID'];
	$student = new Student();
	$singlestudent = $student->single_student_userid($id); 
	$accountID = $singlestudent->scholar_id;
	echo "Elcid: " . $accountID . "<br>";

?>
		<?php 
	

		// $mydb->setQuery("SELECT * from FROM scholar_info WHERE user_id = $id;");
		// $account = $mydb->loadSingleResult();
		// $accountID = $account->scholar_id;
		// echo "Account ID: " . $accountID . "<br>";


		$mydb->setQuery("SELECT scholar_id, ABS((COUNT(*) - COUNT(NULLIF(firstname, '')) - COUNT(NULLIF(middlename, '')) - COUNT(NULLIF(lastname, '')) - COUNT(NULLIF(suffix, '')) 
		- COUNT(NULLIF(age, '')) - COUNT(NULLIF(gender, '')) - COUNT(NULLIF(address, '')) - COUNT(NULLIF(presentaddress, '')) - COUNT(NULLIF(birthdate, '')) - COUNT(NULLIF(email, ''))
		- COUNT(NULLIF(phone_num, '')) - COUNT(NULLIF(telephone_number, '')) - COUNT(NULLIF(religion, '')) - COUNT(NULLIF(citizenship, '')) - COUNT(NULLIF(OFW_firstname, '')) 
		- COUNT(NULLIF(OFW_middlename, '')) - COUNT(NULLIF(OFW_lastname, '')) - COUNT(NULLIF(OFW_suffix, '')) 
		- COUNT(NULLIF(OFW_relationship, '')) - COUNT(NULLIF(category, '')) - COUNT(NULLIF(school, '')) - COUNT(NULLIF(school_address, '')) - COUNT(NULLIF(program, '')) 
		- COUNT(NULLIF(number_siblings, '')) - COUNT(NULLIF(fatherstatus, '')) - COUNT(NULLIF(father_fname, '')) - COUNT(NULLIF(father_mname, '')) - COUNT(NULLIF(father_lname, '')) 
		- COUNT(NULLIF(father_suffix, '')) - COUNT(NULLIF(father_occupation, '')) - COUNT(NULLIF(father_contactnum, '')) - COUNT(NULLIF(Father_Educ, '')) - COUNT(NULLIF(father_email, '')) 
		- COUNT(NULLIF(motherstatus, '')) - COUNT(NULLIF(mother_fname, '')) - COUNT(NULLIF(mother_mname, '')) - COUNT(NULLIF(mother_lname, '')) - COUNT(NULLIF(mother_suffix, '')) 
		- COUNT(NULLIF(mother_occupation, '')) - COUNT(NULLIF(mother_contactnum, '')) - COUNT(NULLIF(mother_email, '')) - COUNT(NULLIF(mother_Educ, '')) - COUNT(NULLIF(Course, '')) 
		- COUNT(NULLIF(year_level, '')) - COUNT(NULLIF(primary_school, '')) - COUNT(NULLIF(primary_year_from, '')) - COUNT(NULLIF(primary_year_to, '')) - COUNT(NULLIF(primary_award, '')) 
		- COUNT(NULLIF(secondary_school, '')) - COUNT(NULLIF(secondary_year_from, '')) - COUNT(NULLIF(secondary_year_to, '')) - COUNT(NULLIF(secondary_award, '')) - COUNT(NULLIF(tertiary_school, '')) 
		- COUNT(NULLIF(tertiary_year_from, '')) - COUNT(NULLIF(tertiary_year_to, '')) - COUNT(NULLIF(tertiary_award, '')) - COUNT(NULLIF(remarks, '')) - COUNT(NULLIF(graduate, '')) 
		- COUNT(NULLIF(graduated_at, ''))) / 59 * 100) AS PercentageFilled
		FROM scholar_info
		WHERE scholar_id = $accountID;
		");
		
		$result = $mydb->loadSingleResult();
		
		if ($result) {
			echo "Scholar ID: " . $result->scholar_id . "<br>";
			echo "Percentage of Filled Fields: " . $result->PercentageFilled . "%";
		} else {
			echo "No record found.";
		}
		
			?>

<canvas id="chartCanvas" width="200" height="200"></canvas>
<script>
	var canvas = document.getElementById("chartCanvas");
var ctx = canvas.getContext("2d");

var percentageFilled = <?php echo $result->PercentageFilled; ?>;
var currentAngle = 0;
var startAngle = -Math.PI / 2;
var angleIncrement = 0.05; // Adjust the value to increase/decrease animation speed

function drawChart() {
  // Clear the canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw the background circle
  ctx.beginPath();
  ctx.arc(canvas.width / 2, canvas.height / 2, canvas.width / 2 - 10, 0, 2 * Math.PI);
  ctx.lineWidth = 10;
  ctx.strokeStyle = "#f2f2f2";
  ctx.stroke();

  // Draw the filled arc
  ctx.beginPath();
  ctx.arc(canvas.width / 2, canvas.height / 2, canvas.width / 2 - 10, startAngle, currentAngle);
  ctx.lineWidth = 10;
  ctx.strokeStyle = "#007bff";
  ctx.stroke();

  // Draw the text
  ctx.fillStyle = "#333";
  ctx.font = "bold 24px Arial";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(percentageFilled.toFixed(2) + "%", canvas.width / 2, canvas.height / 2);

  // Animate the chart
  if (currentAngle < (2 * Math.PI * percentageFilled) / 100 + startAngle) {
    currentAngle += angleIncrement;
    requestAnimationFrame(drawChart);
  }
}

// Start the animation
drawChart();


</script>

	<div class="row">
			<div class="col-lg-12">
				<h3 >Student Profile</h3>
				<?php   
				$id =  $_SESSION['USERID'] ;
				  		// $mydb->setQuery("SELECT * 
								// 			FROM  `tblusers` WHERE TYPE != 'Customer'");
				  		$mydb->setQuery("SELECT * 
											FROM  `scholar_info` where user_id = $id ");
				  		$cur = $mydb->loadResultList();

						foreach ($cur as $result) {
							
							
?>

<div class="student-profile py-4">
	<!-- the whole student form -->  
	<div class="container">
		<!-- table  -->
    <div class="row">
      <div class="col-lg-4">
        <div class="card shadow-m">
          <div class="card-header bg-transparent text-center">
            <img class="profile_img" src="C:\xampp\htdocs\OWWASPOM\images\profile.jpg" alt="student dp">
            <h5><?php echo $result-> firstname; ?>   
			<?php echo $result-> middlename; ?>     
            <?php echo $result-> lastname; ?>   
            </h5>
          </div>
          <div class="card-body">
            <p class="mb-0"><strong class="pr-1">Scholar ID:</strong><?php echo $result-> scholar_id; ?>   </p>
            <p class="mb-0"><strong class="pr-1">Scholarship Program:</strong><?php echo $result-> program; ?>   </p>
            <p class="mb-0"><strong class="pr-1">School:</strong><?php echo $result-> school; ?>   </p>
            <p class="mb-0"><strong class="pr-1">Year:</strong><?php echo $result-> year_level; ?>   </p>
          </div>
        </div>
      </div>
	  
      <div class="col-lg-8">
        <div class="card shadow-sm">
			<div class="card-body bg-transparent border-0">
			<div class = "text-right">
				<a href="index.php?view=editme&id= <?php echo $result->scholar_id?>">
				<button type="button" class="btn btn-success btn-floating">
				<i class="fa fa-pencil-square-o"></i>
				</button>
						</a>
						</div>
				<h4 class="mb-0"><i class="fa fa-user pr-3"></i>Scholars Information 
				</h4>
				
			</div>
			
				<div class="card-body pt-0">
					<table class="table table-hover table-sm">
					<tr>
						<td width="50%"><strong>Permanent Address </strong>:<?php echo $result-> address; ?>   </td>
						<td width="50%"><strong>Present address :	</strong><?php echo $result-> presentaddress; ?>   </$td>
					</tr>
				
					<tr>
						<td width="50%"><strong>Gender: </strong><?php echo $result->gender; ?>   </td>
						<td width="50%"><strong>Age: </strong><?php echo $result->age; ?>   </td>
					</tr>
					<tr>
						<td width="50%"><strong>Birthday : </strong><?php echo $result->birthdate; ?>   </td>
						<td width="50%"><strong>Place of Birth : </strong></td>
						
					</tr>
					<tr>
						<td width="50%"><strong>Telephone Number: </strong></td>
						<td width="50%"><strong>Cellphone Number : </strong><?php echo $result->phone_num; ?> </td>
						
					</tr>
					<tr>
						<td width="50%"><strong>Religion : </strong><?php echo $result-> religion; ?> </td>
						<td width="50%"><strong>Citizenship : </strong><?php echo $result-> citizenship; ?> </td>
					</tr>
					</table>
				</div>
				
        </div>
		
	
    </div>
		<!-- end of table -->
		
  </div>
	<!-- end of whole student form -->
	
</div>

<div class="student-profile py-4">
	<!-- Relationship to OFW form -->  
	<div class="container">
		<!-- table  -->
    <div class="row">
      <div class="col-lg-4">
        <div class="card shadow-m">
          <div class="card-header bg-transparent text-center">
		  <h4>Relationship to OFW </h4><br>
          </div>
          <div class="card-body">
		 
            <h5>Name of the OFW : <?php echo $result-> OFW_firstname; ?> 
					<?php echo $result-> OFW_middlename; ?> 
					<?php echo $result-> OFW_lastname; ?>  
						</h5>
            <p class="mb-0"><strong class="pr-1">Relationship :	</strong><?php echo $result-> OFW_relationship; ?></p>
            <p class="mb-0"><strong class="pr-1">Category: </strong><?php echo $result-> category; ?>  </p>
          </div>
        </div>
      </div>
	  
      <div class="col-lg-8">
        <div class="card shadow-sm">
			<div class="card-body bg-transparent border-0">
			<div class = "text-right">
			<a href="index.php?view=editfam&id= <?php echo $result->scholar_id?>">
				<button type="button" class="btn btn-success btn-floating">
				<i class="fa fa-pencil-square-o"></i>
				</button>
						</a>
						</div>
				<h4 class="mb-0"><i class="fas fa-user-circle pr-3"></i>Family background</h4>
			</div>
				<div class="card-body pt-0">
					<table class="table table-hover table-sm">
					<tr>
						<td width="50%"><strong class="pr-3">Number of siblings :</strong><?php echo $result-> number_siblings; ?>   </td>
					</tr>
					<tr>
						<th>Father's information</th>
						<td></td>
					</tr>
					<tr>
						<td width="50%"><strong>Name: </strong> <?php echo $result-> father_fname; ?> 
												<?php echo $result-> father_mname; ?> 
												<?php echo $result-> father_lname; ?> </td>
						<td width="50%"><strong> Status: </strong><?php echo $result->fatherstatus; ?>   </td>
					</tr>
					<tr>
						<td width="50%"><strong>Occupation: </strong><?php echo $result-> father_occupation; ?>   </td>
						<td width="50%"><strong>Educational Attainment: </strong><?php echo $result->Father_Educ; ?>   </td>
					</tr>
					<tr>
						<td width="50%"><strong>Contact numbers:  </strong><?php echo $result->father_contactnum; ?>  </td>
						<td width="50%"></td>
					</tr>
					<tr>
						<th>Mother's information</th>
						<td></td>
					</tr>
					<tr>
						<td width="50%"><strong>Name: </strong><?php echo $result-> mother_fname; ?> 
												<?php echo $result-> mother_mname; ?> 
												<?php echo $result-> mother_lname; ?>     </td>
						<td width="50%"><strong>Status: </strong><?php echo $result->motherstatus; ?>   </td>
					</tr>
					<tr>
						<td width="50%"><strong>Occupation: </strong><?php echo $result-> mother_occupation; ?>   </td>
						<td width="50%"><strong>Educational Attainment: </strong><?php echo $result->mother_Educ; ?>   </td>
					</tr>
					<tr>
						<td width="50%"><strong>Contact numbers:  </strong><?php echo $result->mother_contactnum; ?>  </td>
					<td></td>
					</tr>
					</table>
				</div>
				
        </div>
		
	
    </div>
		<!-- end of table -->
						<!-- Whole table -->
						<div style="height: 26px"></div>
						<div class="card shadow-sm">
							
						<div class="card-body bg-transparent border-0">
						<div class = "text-right">
						<a href="index.php?view=edited&id= <?php echo $result->scholar_id?>">
							<button type="button" class="btn btn-success btn-floating">
							<i class="fa fa-pencil-square-o"></i>
							</button>
						</a>
						</div>
							<h4 class="mb-0"><i class="	fas fa-user-friends pr-3"></i>Educational Information</h4>
						</div>
						<div class="card-body pt-0">
							<!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
						</div> -->
						<table class="table table-striped table-hover table-sm">
							<tr>
								<th colspan="3">Primary</th>
							</tr>
							<tr>
								<td><strong>School : <?php echo $result-> primary_school; ?>  </strong></td>
								<td><strong>Period of Attendance :</strong><?php echo $result-> primary_year_from; ?> -
								<?php echo $result-> primary_year_to; ?> </td>
							</tr>
							<th colspan="3">Secondary</th>
							<tr>
								<td><strong>School : </strong> <?php echo $result-> secondary_school; ?>  </td>
								<td><strong>Period of Attendance :</strong><?php echo $result-> secondary_year_from; ?> -
								<?php echo $result-> secondary_year_to; ?> </td>
							
							</tr>

							<tr>
							<th colspan="3">Tertiary</th>
							</tr>
							<tr>
								<td><strong>School : </strong> <?php echo $result-> school; ?>  </td>
								<td><strong>Period of Attendance :</strong><?php echo $result-> tertiary_year_from; ?> -
								<?php echo $result-> tertiary_year_to; ?> </td>
							</tr>

							
				</table> 
						</div>
						
					</div>
					<!-- end of whole table --> 	
					<!-- Whole table -->
					<div style="height: 26px"></div>
						<div class="card shadow-sm">
							
						<div class="card-body bg-transparent border-0">
						<div class = "text-right">
						<a href="index.php?view=editapp&id= <?php echo $result->scholar_id?>">
							<button type="button" class="btn btn-success btn-floating">
							<i class="fa fa-pencil-square-o"></i>
							</button></a>
									</div>
							<h4 class="mb-0"><i class="	fas fa-user-friends pr-3"></i>Scholar Application Information</h4>
						</div>
						<div class="card-body pt-0">
						<table class="table table-striped table-hover table-sm">
							<tr>
								<td colspan="2"><strong>Name of School : <?php echo $result-> school; ?>  </strong></td>
							</tr>
							<tr>
								<td><strong>Course :  </strong> <?php echo $result-> Course; ?>  </td>
								<td><strong>Year Level :  </strong><?php echo $result-> year_level; ?> 
							
							</tr>			
				</table> 
						</div>
						
					</div>
					<!-- end of whole table --> 	
  </div>
	<!-- end of whole student form -->
	
</div>
       
	   
    
	<?php
}
?>